Rolnik TYCOON — v0.8.3b (praca mh + zlecenia + siew/zbiór + stodoła)

1) npm install
2) npm run dev
Jeśli zobaczysz błąd PostCSS o tailwindcss ->
   npm i -D @tailwindcss/postcss
i uruchom ponownie.
