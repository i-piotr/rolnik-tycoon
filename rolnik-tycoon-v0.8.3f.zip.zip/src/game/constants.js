export const START_DATE=new Date(1946,0,1); export const END_DATE_EXCLUSIVE=new Date(2000,0,1);
export const TOTAL_FARM_M2=10000; export const SETTLEMENT_M2=2600; export const OPEN_FIELD_AREA_M2=TOTAL_FARM_M2-SETTLEMENT_M2;
export const MIN_PLOT_M2=500; export const START_MONEY=1000;
